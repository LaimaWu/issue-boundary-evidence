# IBE Prospective Shadow Freeze v0.1.0

This directory is a raw prospective snapshot and CLI-output freeze. It contains no evaluation, scoring, interpretation, or source-code changes.

## Release environment

- Repository: `https://github.com/LaimaWu/issue-boundary-evidence.git`
- Release tag: `v0.1.0`
- Release SHA: `0a21ea25ce03bcc68ef32a6b477244089dcf5ecd`
- Python: `3.12.14`
- Installed package version: `0.1.0`
- GitHub API access mode: anonymous public API
- Clone worktree status: clean
- Cases attempted: 10
- Cases frozen: 10
- Open at freeze: 10
- Closed before freeze: 0
- CLI failures: 0

## Frozen cases

All timestamps are UTC. Each case directory contains the raw issue response, raw paginated comments response, response headers, unmodified CLI Markdown report, CLI stdout and stderr, exit code, and machine-readable snapshot metadata.

| Case | Issue URL | Snapshot started | Snapshot completed | State | Issue HTTP | Comment pages | CLI exit | Directory |
|---:|---|---|---|---|---:|---:|---:|---|
| 01 | https://github.com/scikit-learn/scikit-learn/issues/34977 | 2026-09-19T11:43:12Z | 2026-09-19T11:43:15Z | open | 200 | 1 | 0 | `cases/01-scikit-learn-scikit-learn-34977/` |
| 02 | https://github.com/scikit-learn/scikit-learn/issues/34975 | 2026-09-19T11:43:15Z | 2026-09-19T11:43:17Z | open | 200 | 1 | 0 | `cases/02-scikit-learn-scikit-learn-34975/` |
| 03 | https://github.com/astral-sh/uv/issues/21829 | 2026-09-19T11:43:17Z | 2026-09-19T11:43:20Z | open | 200 | 1 | 0 | `cases/03-astral-sh-uv-21829/` |
| 04 | https://github.com/astral-sh/uv/issues/21720 | 2026-09-19T11:43:20Z | 2026-09-19T11:43:22Z | open | 200 | 1 | 0 | `cases/04-astral-sh-uv-21720/` |
| 05 | https://github.com/matplotlib/matplotlib/issues/32339 | 2026-09-19T11:43:22Z | 2026-09-19T11:43:25Z | open | 200 | 1 | 0 | `cases/05-matplotlib-matplotlib-32339/` |
| 06 | https://github.com/matplotlib/matplotlib/issues/32329 | 2026-09-19T11:43:25Z | 2026-09-19T11:43:28Z | open | 200 | 1 | 0 | `cases/06-matplotlib-matplotlib-32329/` |
| 07 | https://github.com/pydantic/pydantic/issues/13835 | 2026-09-19T11:43:28Z | 2026-09-19T11:43:30Z | open | 200 | 1 | 0 | `cases/07-pydantic-pydantic-13835/` |
| 08 | https://github.com/pydantic/pydantic/issues/13834 | 2026-09-19T11:43:30Z | 2026-09-19T11:43:34Z | open | 200 | 1 | 0 | `cases/08-pydantic-pydantic-13834/` |
| 09 | https://github.com/psf/requests/issues/7620 | 2026-09-19T11:43:34Z | 2026-09-19T11:43:37Z | open | 200 | 1 | 0 | `cases/09-psf-requests-7620/` |
| 10 | https://github.com/psf/requests/issues/7610 | 2026-09-19T11:43:37Z | 2026-09-19T11:43:41Z | open | 200 | 1 | 0 | `cases/10-psf-requests-7610/` |

## Per-case files

- `issue.json`: raw GitHub public issue API response body
- `issue.headers.txt`: raw response headers for the issue request
- `comments-page-001.json`: raw GitHub public comments API response body
- `comments-page-001.headers.txt`: raw response headers for the comments request
- `report.md`: raw Markdown report emitted by `issue-boundary-evidence` v0.1.0
- `cli.stdout.txt`: CLI standard output
- `cli.stderr.txt`: CLI standard error
- `cli.exit-code.txt`: CLI process exit code
- `metadata.json`: URL, timestamps, state, HTTP status, pagination completeness, authentication mode, and CLI result

## Setup evidence

- `setup/clone.stdout.txt`
- `setup/clone.stderr.txt`
- `setup/install.stdout.txt`
- `setup/install.stderr.txt`
- `setup/cli-help.stdout.txt`
- `setup/cli-help.stderr.txt`
- `setup/environment.txt`

`SHA256SUMS.txt` records SHA-256 digests for the manifest and every frozen setup and case artifact.
