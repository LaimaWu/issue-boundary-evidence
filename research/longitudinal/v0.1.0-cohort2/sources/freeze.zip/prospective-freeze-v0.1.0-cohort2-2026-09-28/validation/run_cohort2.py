import concurrent.futures
import json
import os
import platform
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path

def utc(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
base=Path('prospective-freeze-v0.1.0-cohort2-2026-09-28/cases')
dirs=sorted(x for x in base.iterdir() if x.is_dir())
src=str(Path('engine-v0.1.0/src').resolve())
def one(d):
 m=json.loads((d/'metadata.json').read_text()); env=os.environ.copy(); env.pop('GITHUB_TOKEN',None);env['PYTHONPATH']=src
 cmd=[sys.executable,'-m','issue_boundary_evidence.cli',m['issue_url'],'-o',str((d/'report.md').resolve())]
 began=utc()
 try:
  p=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=150)
  code=p.returncode;out=p.stdout;err=p.stderr
 except subprocess.TimeoutExpired as e:
  code=124;out=(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout,bytes) else (e.stdout or '');err=(e.stderr or b'').decode(errors='replace') if isinstance(e.stderr,bytes) else (e.stderr or '')
 ended=utc()
 (d/'cli.stdout.txt').write_text(out);(d/'cli.stderr.txt').write_text(err);(d/'cli.exit-code.txt').write_text(str(code)+'\n')
 (d/'execution.json').write_text(json.dumps({'cli_invocation':cmd,'cwd':str(Path.cwd()),'started_utc':began,'completed_utc':ended,'exit_code':code,'report_present':(d/'report.md').exists(),'python':platform.python_version(),'github_token_present':False,'pythonpath':src,'engine_commit':'0a21ea25ce03bcc68ef32a6b477244089dcf5ecd'},indent=2)+'\n')
 return {'case':d.name,'exit_code':code,'report_present':(d/'report.md').exists(),'stderr':err[:200]}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
 for x in pool.map(one,dirs): print(json.dumps(x),flush=True)
